package practs.pract_10;

public class _1 {
}
