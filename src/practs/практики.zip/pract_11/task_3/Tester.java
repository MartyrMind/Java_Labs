package practs.pract_11.task_3;

import java.util.Date;

public class Tester {
    public static void main(String[] args) {
        Student student = new Student("Иван", "Иванов", new Date());
        System.out.println(student);
        System.out.println(student);
        System.out.println(student);
        System.out.println(student);
        System.out.println(student);
        System.out.println(student);

    }
}
