package practs.pract_14.task_8;

public interface Filter {
    boolean apply(Object o);
}
