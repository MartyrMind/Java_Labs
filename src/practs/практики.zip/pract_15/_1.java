package practs.pract_15;

public class _1 {
}
