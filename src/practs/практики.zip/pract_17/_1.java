package practs.pract_17;

public class _1 {
}
