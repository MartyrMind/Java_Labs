package practs.pract_17.task_2;

public class EmployeeView {
    public void printEmployeeDetails(String employeeName, String employeePosition, int salary){
        System.out.println("Employee: ");
        System.out.println("Name: " + employeeName);
        System.out.println("Position: " + employeePosition);
        System.out.println("Salary: " + salary + "\n");
    }
}
