package practs.pract_19;

public class EmptyStringException extends IllegalArgumentException{
    public EmptyStringException(String message) {
        super(message);
    }
}
