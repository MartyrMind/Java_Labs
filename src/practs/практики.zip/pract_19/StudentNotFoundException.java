package practs.pract_19;

public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}

