package practs.pract_20.task_2;

public class Animal {
}
