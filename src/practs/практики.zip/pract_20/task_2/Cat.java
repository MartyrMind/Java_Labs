package practs.pract_20.task_2;

import java.io.Serializable;

public class Cat extends Animal implements Serializable {
}
