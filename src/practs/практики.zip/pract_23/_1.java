package practs.pract_23;

public class _1 {
}
