package practs.pract_24;

public abstract interface ICreateDocument {
    abstract IDocument createNew();
    abstract IDocument createOpen();
}
