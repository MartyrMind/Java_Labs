package practs.pract_29;

public class IllegalTableNumber extends Error {
    public IllegalTableNumber(String message) {
        super(message);
    }
}
