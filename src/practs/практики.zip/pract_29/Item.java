package practs.pract_29;

public interface Item {
    abstract double cost();
    abstract String name();
    abstract String description();

}
