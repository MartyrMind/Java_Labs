package practs.pract_30;

public interface Alcoholable {
    public boolean isAlcoholicDrink();
    public double getAlcoholVol();
}
