package practs.pract_6;

public class _1 {
}
