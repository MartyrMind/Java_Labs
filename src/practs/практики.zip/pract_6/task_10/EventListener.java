package practs.pract_6.task_10;

public interface EventListener {
    public void update(String eventType, StringBuilder op, String data);
}
