package practs.pract_6.task_3;

public interface Nameable {
    String getName();
}
