package practs.pract_6.task_4;

public interface Priceable {
    int getPrice();
}
