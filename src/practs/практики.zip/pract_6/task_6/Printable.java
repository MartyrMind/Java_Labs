package practs.pract_6.task_6;

public interface Printable {
    void print();
}
