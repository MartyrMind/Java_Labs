package practs.pract_6.task_8;

public interface Convertable {
    void convert(Convertable from);
}
