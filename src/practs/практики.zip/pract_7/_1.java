package practs.pract_7;

public class _1 {
}
