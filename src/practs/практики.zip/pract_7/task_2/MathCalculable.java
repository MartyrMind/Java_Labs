package practs.pract_7.task_2;

public interface MathCalculable {
    double PI = Math.PI;
    public ComplexNumber pow(ComplexNumber number, int n);
    public double abs(ComplexNumber number);

}
