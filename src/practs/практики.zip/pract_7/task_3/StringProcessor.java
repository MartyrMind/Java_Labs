package practs.pract_7.task_3;

public interface StringProcessor {
    int cntLiter(String str);
    String substring(String str);
    String reverse(String str);
}
