package practs.pract_7.task_4;

public interface Printable {
    void print();
}
