package practs.pract_9;

public class _1 {
}
