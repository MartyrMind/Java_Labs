package practs.pract_9.task_4;

public interface MyComparable {
    int myCompareTo(Object o);
}
